//所有DOM效果的固定套路:
//1. 查找触发事件的元素
var d2=document.getElementById("packup-sidebar-d1");
console.log(d2);
var d1=document.getElementById("packup-sidebar-d2");
var unfoldSidebar=document.getElementsByClassName("unfold-sidebar")[0];
var packupSidebar=document.getElementsByClassName("packup-sidebar")[0];
var packupSidebar=document.getElementsByClassName("packup-sidebar")[0];
var sortZonhe=document.getElementById("sort-zonhe");
	console.log(sortZonhe);
var span1=document.getElementById("span1");
	console.log(span1);
var sort=document.getElementsByClassName("sort-3")[0];
	console.log(sort);
var dsad=document.getElementsByClassName("dsad")[0];
	console.log(dsad);
var cleart=document.getElementById("cleart");

//2. 为元素绑定事件处理函数

	//3. 查找要修改的元素
//	var d1=document.getElementById("packup-sidebar-d2");
	console.log(d1);
//	var sortZonhe=document.getElementById("sort-zonhe");
//	console.log(sortZonhe);
//	var span1=document.getElementById("span1");
//	console.log(span1);
//	var sort=document.getElementsByClassName("sort-3")[0];
//	console.log(sort);
//	var dsad=document.getElementsByClassName("dsad")[0];
//	console.log(dsad);

	var d2=this;
	//4. 修改元素
	//如果d2的内容是<<，就关闭
	if(span1.innerHTML=="&gt;"){
		//d1.style.display="none";
		d1.style.display="block";
		unfoldSidebar.style.display="block";
		cleart.style.clear="left";
        sortZonhe.style.width="966px";
		d2.style.display="none";
		sort.style.width="970px";
		dsad.style.width="970px";
		sort.style.float="right";

	}
}
 var em1=document.getElementById("em1");
		console.log(em1);
		em1.onclick=function(){
			var em1=this;
			if(em1.innerHTML=="&lt;收起侧栏"){
		    d1.style.display="none";
            sortZonhe.style.width="1080px";
		    d2.style.display="block";
		    sort.style.width="1210px";
		    dsad.style.width="1210px";
			unfoldSidebar.style.display="none";
			packupSidebar.style.display="block";
			}
		}
	
