var YRUwBU1=document.getElementById("YRUwBU1");
console.log(YRUwBU1);

YRUwBU1.innerHTML=` <div class="tou_d1"><img src="../image/header/1556242284689.jpg"/></div>
	 <div class="site_nav">
	     <ul class="site_nav_ul1">
		   <li class="site_nav_ul1_li1"><a href="#"><span class="site_nav_span1"></span></a></li>
		   <li class="site_nav_ul1_li2"><a href="#">当前城市:武汉</a></li>
		   <li class="site_nav_ul1_li8"><a href="#"><span class="site_nav_span2"></span></a></li>
		   <li class="site_nav_ul1_li3"><a href="#">hi，欢迎来我买网</a></li>
		   <li class="site_nav_ul1_li4"><a href="#">登录</a></li>
		   <li class="site_nav_ul1_li9"><a href="#">注册</a></li>
		   <li class="site_nav_ul1_li5"><a href="#">我的账户</a></li>
		   <li class="site_nav_ul1_li8"><a href="#"><span class="site_nav_span2"></span></a></li>
		   <li class="site_nav_ul1_li7"><a href="#"><span class="site_nav_span3"></span></a></li>
		   <li class="site_nav_ul1_li6"><a href="#">购物车0件</a></li>
		   <li class="site_nav_ul1_li10"><a href="#">客户服务</a></li>
		   <li class="site_nav_ul1_li8"><a href="#"><span class="site_nav_span2"></span></a></li>
		   <li><a href="#">企业购</a></li>
		   <li><a href="#"><span class="site_nav_span4"></span></a></li>
		   <li><a href="#"><span class="site_nav_span5"></span></a></li>
		 </ul>
	  </div>
	  <div class="logo_d1" id="parent">
	     <a href="#"><img class="" src="../image/header/1550196020862.png"/></a>
		 <a href="#" class="logo_input12"><img class="" src="../image/header/1556164204910.gif"/></a>
		 <a href="#" class="" id="logo_input"></a>
		 <input class="logo_input" type="text" value="吃货秘籍抢先看 新品0元任性送"/><a class="logo_sosuo" href="#">搜索</a>
		 <a class="logo_right" href="#"><img src="../image/header/1493101441030.jpg"/></a>
	  </div>
`;
