
$(function(){
        //定义一个常量控制图片的切换
        var count = 0;
        //找到要切换的元素li
        var $li = $(".banner_center>.banner_center_d1>ul>li");

        //设置定时器中的调用函数
        var task=function(){
            count++;
            if(count == $li.length){
                count =0;
            }
            $li.eq(count).fadeIn().siblings().fadeOut();
            $(".slider_icon i").eq(count).addClass("btn_act").siblings().removeClass('btn_act');
            //console.log(count);
        };
        //设置定时器
        var timer=setInterval(task,2500);
        //鼠标移入事件（鼠标移入时停止定时器）
     $(".banner_center>.banner_center_d1").mouseover(function(){
         clearInterval(timer);timer=null;
            //console.log("asd");
        })
       //鼠标移出事件（鼠标移出时启动定时器）
        $(".banner_center>.banner_center_d1").mouseleave(function(){
            timer=setInterval(task,2500);
           // console.log("111asd");
        })


        //设置右边的切换按钮
        $(".next").click(function(){
            count++;
            if(count == $li.length){
                count =0;
            }
            $li.eq(count).fadeIn().siblings().fadeOut();
            $(".slider_icon i").eq(count).addClass("btn_act").siblings().removeClass('btn_act');
            console.log(count);
        });
     //设置左边的切换按钮
        $(".prve").click(function(){
            count--;
            if(count == -1){
                count = $li.length-1;
            }
            console.log(count);
            $li.eq(count).fadeIn().siblings().fadeOut();
            $(".slider_icon i").eq(count).addClass("btn_act").siblings().removeClass('btn_act');
        });
        $(".slider_icon i").mouseenter(function(){
            $(this).addClass('btn_act').siblings().removeClass("btn_act");
            $li.eq($(this).index()).fadeIn().siblings().fadeOut();
            count = $(this).index();
        });
    });






