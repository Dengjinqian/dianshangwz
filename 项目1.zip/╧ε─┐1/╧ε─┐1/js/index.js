function naver(id){
    var obj = document.getElementById(id);
    var oPos = obj.offsetTop;
    return window.scrollTo(0, oPos-36);
}