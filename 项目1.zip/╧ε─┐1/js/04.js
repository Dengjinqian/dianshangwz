var d2=document.getElementById("YRUwBU");

d2.innerHTML=`
<div class="foorter">
	   <table></table>
	   <div class="foorter_bottom gaodutanta">
		  <ul>
			 <li><a href="#"><h3>新手上路</h3></a></li>
			 <li><a href="#">新用户演示</a></li>
			 <li><a href="#">会员积分计划</a></li>
			 <li><a href="#">会员等级规则</a></li>
			 <li><a href="#">售后服务政策</a></li>
			 <li><a href="#">我买网发票制度</a></li>
		  </ul>
		   <ul>
			 <li><a href="#"><h3>付款方式</h3></a></li>
			 <li><a href="#">支付方式</a></li>
			 <li><a href="#">支付常见问题</a></li>
			 <li><a href="#">激活礼品卡</a></li>
			 <li><a href="#">我买卡</a></li>
			 <li><a href="#">电子礼品卡说明及使用</a></li>
		  </ul>
		   <ul>
			 <li><a href="#"><h3>新手上路</h3></a></li>
			 <li><a href="#">新用户演示</a></li>
			 <li><a href="#">会员积分计划</a></li>
			 <li><a href="#">会员等级规则</a></li>
			 <li><a href="#">售后服务政策</a></li>
			 <li><a href="#">我买网发票制度</a></li>
		  </ul>
		  <ul>
			 <li><a href="#"><h3>新手上路</h3></a></li>
			 <li><a href="#">新用户演示</a></li>
			 <li><a href="#">会员积分计划</a></li>
			 <li><a href="#">会员等级规则</a></li>
			 <li><a href="#">售后服务政策</a></li>
			 <li><a href="#">我买网发票制度</a></li>
		  </ul>
		  <ul class="fooretr_ulapp"> 
			 <li><a href="#">中粮我买网APP</a></li>
			 <li><a href="#"><img src="../image/foorter/11.png"/></a></li>
			 </li>
		  </ul>
		   <ul class="fooretr_ulapp">
			  <li><a href="#">中粮我买网APP</a></li>
			  <li><a href="#"><img src="../image/foorter/12.jpg"/></a></li>
		  </ul>
	   </div>
</div>
<div class="foorter1">
  <div class="foorter1_d1 gaodutanta">
     <ul>
		<li>关于我们</li>
		<span>|</span>
		<li>免责条款</li>
		<span>|</span>
		<li>中粮集团</li>
		<span>|</span>
		<li>服务协议</li>
		<span>|</span>
		<li>隐私协议</li>
		<span>|</span>
		<li>友情链接</li>
		<span>|</span>
		<li>搜索热词</li>
		<span>|</span>
		<li>客服电话：400-005-5678</li>
		<span>|</span>
		<li>企业采购热线：4008-117-588</li>
	 </ul>
	 <ul class="foorter1_d1_ultup">
		   <li>
			 <img src="../image/foorter/13.png"/>
		   </li>
	  </ul>
	  <div class="foorter1_d1_ul2tup">
	    <ul>
	      <li>Copyright©2009-2018 womai.com.hk All Rights Reserved 中粮海优（北京）有限公司版权所有</li>
		  <li>中粮海优（北京）有限公司 北京市朝阳区朝阳门南大街8号18F-09室</li>
		  <li><span class="foorter1_d1_ul2tup_span"></span> <span class="foorter1_d1_ul2tup_span1">京公网安备 11010102000458号   京ICP备 13003995号</span> </li>
		  <li>营业执照（统一社会信用代码）91110000055590239L  食品经营许可证：JY11105020028185</li>
		  <li class="foorter1_d1_ul2tup_li"></li>
		  </ul>
	  </div>
  </div>
</div>
`;