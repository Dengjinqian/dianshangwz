var bannerSpfnei=document.getElementsByClassName("banner_spfnei")[0];
console.log(bannerSpfnei);
var banner=document.getElementsByClassName("banner")[0];
var redut=document.getElementsByClassName("redut")[0];
console.log(redut);
redut.onmouseover=function(){
    banner.style.display="block";
    banner.style.width="210px";
    banner.style.height="450px";
}
redut.onmouseout=function(){
    banner.style.display="none";
}